module.exports = {
    SECRET: "turangalella",
    DB_PASSWORD: "q1W@e3R$t5",
    DB_USER: "root",
    DB_HOST: "localhost",
    DB_NAME: "festivalDB",
    SALT_ROUND: 10,
    SENGRID_API_KEY: "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"
}