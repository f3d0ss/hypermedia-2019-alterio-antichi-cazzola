# Hypermedia Project

This is a site for a festival!

### How to start the server
- run `npm install` to install the dependeces
- start a MySQL server with an user with username and password specified in the [configuration file](configuration/configuration.js)
- run `node util/create-database.js` to create the database and the tables needed
- last but not list start the rever with `node app.js` (or `nodemond app.js` if you have it)


### Donation
- **Ethereum** : 0x5E8c70bBeba85115D51ee3ED350a0C6b56f8E6CE
